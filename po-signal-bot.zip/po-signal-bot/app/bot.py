from __future__ import annotations

import asyncio
from typing import Dict

from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import settings
from app.logger import log
from app.market_data import PocketOptionWSClient
from app.models import Candle
from app.strategies.strategy_1m import analyze_1m

# Seule la stratégie M1 est active pour l'instant.
# strategy_2m / strategy_5m restent dans le repo, prêtes à être rebranchées
# ici plus tard (il suffira de les réimporter et de les rajouter à STRATEGY_MAP).
router = Router()

STRATEGY_MAP = {1: analyze_1m}
ACTIVE_TIMEFRAMES = [1]

# état de scan par chat (activé/désactivé)
scan_state: Dict[int, Dict] = {}


def main_menu_kb(chat_id: int) -> InlineKeyboardMarkup:
    active = scan_state.get(chat_id, {}).get("active", False)
    toggle_label = "⏸ Arrêter le scan" if active else "▶️ Démarrer le scan (M1)"
    buttons = [
        [InlineKeyboardButton(text=toggle_label, callback_data="toggle_scan")],
        [InlineKeyboardButton(text="📊 Statut", callback_data="status")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def _is_allowed(chat_id: int) -> bool:
    return not settings.allowed_chat_ids or chat_id in settings.allowed_chat_ids


@router.message(Command("start"))
async def cmd_start(message: Message) -> None:
    if not _is_allowed(message.chat.id):
        await message.answer("⛔ Accès non autorisé.")
        return

    scan_state.setdefault(message.chat.id, {"active": False})
    await message.answer(
        "🤖 *Bot de signaux Pocket Option*\n\n"
        "Stratégie active: *M1* — Heikin Ashi + Bollinger(20,2) + "
        "SMA(2)/SMA(5) + RSI(8)\n\n"
        "Choisis une action ci-dessous.\n"
        "⚠️ Ce bot n'exécute *aucun* trade automatiquement : il envoie "
        "uniquement des signaux informatifs.",
        parse_mode="Markdown",
        reply_markup=main_menu_kb(message.chat.id),
    )


@router.callback_query(F.data == "toggle_scan")
async def cb_toggle_scan(callback: CallbackQuery) -> None:
    chat_id = callback.message.chat.id
    state = scan_state.setdefault(chat_id, {"active": False})
    state["active"] = not state["active"]

    if state["active"]:
        await callback.message.answer("🔍 Analyse en cours…⏳ (stratégie M1)")
    else:
        await callback.message.answer("⏸ Scan mis en pause.")

    await callback.message.edit_reply_markup(reply_markup=main_menu_kb(chat_id))
    await callback.answer()


@router.callback_query(F.data == "status")
async def cb_status(callback: CallbackQuery) -> None:
    chat_id = callback.message.chat.id
    state = scan_state.get(chat_id, {})
    active = "✅ actif" if state.get("active") else "⏸ en pause"
    await callback.message.answer(
        f"📊 Statut du scan: {active}\n⏱ Stratégie: M1 uniquement\n💱 Paires: {', '.join(settings.pairs)}"
    )
    await callback.answer()


async def scanning_loop(bot: Bot, provider: PocketOptionWSClient) -> None:
    """Boucle périodique : recalcule les indicateurs et envoie les signaux
    aux chats ayant le scan actif."""
    while True:
        await asyncio.sleep(settings.scan_interval_seconds)

        for chat_id, state in list(scan_state.items()):
            if not state.get("active"):
                continue
            if not _is_allowed(chat_id):
                continue

            for pair in settings.pairs:
                payout = provider.get_payout(pair)
                if payout is not None and payout < settings.min_payout:
                    continue

                for tf in ACTIVE_TIMEFRAMES:
                    candles = provider.get_candles(pair, tf)
                    if len(candles) < 25:
                        continue
                    strategy_fn = STRATEGY_MAP.get(tf)
                    if strategy_fn is None:
                        continue
                    signal = strategy_fn(pair, candles, payout=payout)
                    if signal:
                        try:
                            await bot.send_message(chat_id, signal.to_message())
                        except Exception as exc:  # noqa: BLE001
                            log.error(f"Échec envoi signal à {chat_id}: {exc}")


async def start_bot() -> None:
    bot = Bot(token=settings.telegram_bot_token)
    dp = Dispatcher()
    dp.include_router(router)

    provider = PocketOptionWSClient()

    def _on_candle(pair: str, timeframe: int, candle: Candle) -> None:
        log.debug(f"Nouvelle bougie {pair} {timeframe}min: close={candle.close}")

    market_task = asyncio.create_task(provider.run(_on_candle))
    scan_task = asyncio.create_task(scanning_loop(bot, provider))

    try:
        await dp.start_polling(bot)
    finally:
        market_task.cancel()
        scan_task.cancel()
        await bot.session.close()
